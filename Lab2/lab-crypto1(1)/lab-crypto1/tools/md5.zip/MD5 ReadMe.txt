First, place the given MD5 checksum on the Clipboard (Ctrl C or Edit...Copy)

Run the MD5 Check Utility (MD5.Exe) and this should automatically place the contents of the Clipboard in for you (Paste option). If not, please ensure that you have correctly copied the checksum to the Clipboard, and then click on the Paste button. You can also use the Paste facility for checking more than one MD5 checksum without the need to re-run MD5.Exe (simply copy the next desired checksum to the Clipboard and take the Paste option to refresh the box...then the Browse option).
�
Browse to where your download is and select it by either double left-mouse clicking on it or by highlighting it and taking the 'Open' option.

You may also create your own MD5 checksum(s) if required (for example, to check that a backup file is identical to the original etc.)...just click on the 'Create an MD5 checksum' option (Radio button), and Browse to the required file (and again, select it as per the instructions above) . The result will be automatically placed on the Clipboard for you and an offer to run Windows Notepad is made so that, if you want to, you can Paste (Ctrl+V) the MD5 Code into Notepad and save the result.

MD5 Checker is a completely 'standalone' program that requires no other files (.NET, dll's etc.) to clutter-up your system.

Also, no installation is required - just unzip md5.exe and run it!

Some random thoughts on our new FREE MD5 Checker utility....

It's FREE

No attempt has been made to make this thing pretty (eye candy)

Has been tested on a 2GB+ file with success

It is a simple utility to provide a simple answer: What is/will be the MD5 checksum

Yes, we know it's limitations, and we may attempt a full-blown version with 'full-on' capabilities (unlikely though)

It does not contain the level of sophistication of our Flagship program MidWavi Pro

It's FREE (not to mention it's a tiny full Windows program)

It's FREE!!!


MD5 checksum for MD5.Exe: E5A1A4A431C25A1D8B2428066487FC45


(Tip: To select all of the above checksum, just place your mouse anywhere within the checksum and double left mouse click - then use Ctrl C to copy to the Clipboard)

MD5 Checker 2.30 was written in Emergence Basic from Ionic Wind Software see :

http://www.ionicwind.com

Our web sites:

www.midwavi.com - www.midwavi.co.uk