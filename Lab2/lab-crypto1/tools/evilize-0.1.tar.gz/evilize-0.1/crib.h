/* Copyright (C) 2006 Peter Selinger. This file is distributed under
   the terms of the GNU General Public License. See the file COPYING
   for details. */

/* This byte sequence is used as a placeholder in the compiled
   program. Any sufficiently random 191-character string will do */

#define CRIB "b166892819484778de58f421f1dce377" \
             "e5fa2b5cbb9c194eb9568939b0b8de62" \
             "aa7dc6987a0483f6e8e7b6c2229a147f" \
             "b5c4cf5c182f974654d2d034d912ef27" \
             "5724a172127f667e72dbfa7bfab11b26" \
	     "ab922e1073418d940f6c5458ad6baf4"

