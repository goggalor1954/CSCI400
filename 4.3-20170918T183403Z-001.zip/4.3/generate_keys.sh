#!/bin/bash

# Generate the 384-bit private RSA key.
openssl genpkey -algorithm RSA -out test_private.pem -pkeyopt rsa_keygen_bits:384 > /dev/null 2>&1

# Check if the script was unable to create the private key.
if [[ $? -eq 1 ]]; then
    echo "Failed to generate private key."
    exit 1
fi

# Write the public key.
openssl rsa -in test_private.pem -pubout -out pubkey.pem -text > /dev/null 2>&1

# Check if the script was unable to create the public key.
if [[ $? -eq 1 ]]; then
    echo "Failed to generate public key."
    exit 1
fi

# Generate the generic subject.
subject="/C=US/ST=NY/L=New York/O=John Jay Lab/OU=CSCI 400 Lab/CN=www.jjay.cuny.edu"

# Now generate the host's certificate.
openssl req -new -x509 -nodes -md5 \
    -days 100 -key test_private.pem \
    -subj "$subject" > host.cert

