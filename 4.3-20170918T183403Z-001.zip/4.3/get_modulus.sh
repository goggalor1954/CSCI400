#!/bin/bash

private_key="test_private.pem"

# Generate the keys if they have not yet been generated.
if [ ! -e "$private_key" ]; then
    ./generate_keys.sh
fi

function get_modulus {
    # Ask OpenSSL to get the modulus from the private key.
    ossl=$(openssl rsa -noout -text -in $private_key -modulus)
    echo "$ossl" | grep "^Modulus" | gawk '{print gensub(/^Modulus=/, "", "g", $1) }'
}

# Get the hex value of the modulus.
modulus=$(get_modulus)

# Then get the decimal value of the modulus.
modulus_dec=$(python -c "print int('$modulus', 16)")

# Output the decimal modulus.
echo $modulus_dec

