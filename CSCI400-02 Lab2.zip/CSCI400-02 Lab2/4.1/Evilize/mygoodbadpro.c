
#include <stdio.h>
#include <unistd.h>

/* do something innocent */
int main_good(int ac, char *av[]) {
  char buf[20];
  fprintf(stdout, "Hello, Planet Earth!\n");
  fprintf(stdout, "We Have Water and Foods\n");
  fprintf(stdout, "\n(press enter to quit)");
  fflush(stdout);
  fgets(buf, 20, stdin);
  return 0;
}

/* do something evil */
int main_evil(int ac, char *av[]) {
  char buf[20];
  fprintf(stdout, "This program is evil!!!\n");
  fprintf(stdout, "Erasing hard drive...");
  fprintf(stdout, "Erasing hard drive...");
  fprintf(stdout, "Erasing hard drive...");
  fprintf(stdout, "Erasing hard drive...");
  fprintf(stdout, "Erasing hard drive...");
  fprintf(stdout, "Erasing hard drive...");
  fflush(stdout);
  sleep(1);
  fprintf(stdout, "4Gb...");
  fflush(stdout);
  sleep(1);
  fprintf(stdout, "8Gb...");
  fflush(stdout);
  sleep(1);
  fprintf(stdout, " I was just kidding!\nNothing was erased.\n");
  fprintf(stdout, "\n(press enter to quit)");
  fflush(stdout);
  fgets(buf, 20, stdin);
  return 0;
}
