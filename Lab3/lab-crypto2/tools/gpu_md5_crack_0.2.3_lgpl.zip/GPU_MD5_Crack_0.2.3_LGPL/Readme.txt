Please see all documentations in doc/ directory.
Pre build Linux 32bit executable for Cuda 2.2 is in bin/linux/release/ directory.
 
