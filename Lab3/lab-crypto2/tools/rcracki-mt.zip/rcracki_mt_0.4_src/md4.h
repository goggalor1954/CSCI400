#ifndef MD4_H
#define MD4_H

//typedef unsigned long uint32;
typedef unsigned long UINT4;

//Main function
void MD4_NEW( unsigned char * buf, int len, unsigned char * pDigest);

#endif /* !MD4_H */
