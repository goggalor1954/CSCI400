#ifndef MD5_H
#define MD5_H

typedef unsigned long uint32;

//Main function
void MD5_NEW( unsigned char * buf, int len, unsigned char * pDigest);

#endif /* !MD5_H */
