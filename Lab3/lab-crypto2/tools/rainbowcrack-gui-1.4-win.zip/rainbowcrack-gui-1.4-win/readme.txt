
RainbowCrack 1.4 readme

Introduction
--------------------------------
This is the graphics version of rcrack.exe software.

System Requirements
--------------------------------
Operating System:	any 32-bit version of Windows
Memory:				at least 256MB

Copyright 2003-2009 Project RainbowCrack. All rights reserved.
Official Website: http://project-rainbowcrack.com/
August 17, 2009
